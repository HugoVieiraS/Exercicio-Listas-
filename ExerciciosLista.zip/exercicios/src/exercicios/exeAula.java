package exercicios;


public class exeAula {



	public static void main(String[] args) {
		// exercicio 1
		var ex1 = new exercicio1();
		System.out.println(ex1.somar(1,0,0));
		
		
		//exercicio 2
		var ex = new exercicio2();
		ex.Contar(20);
		
		
		// exericio 3
		var ex3 = new exercicio3();
		ex3.adicionarnotas(5, 6, 7);
		ex3.calcular();
		
	} 

}
