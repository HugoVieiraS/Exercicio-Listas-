package exercicios;


public class exercicio2 extends exeAula {
	public void Contar (int numero){

		
		while (numero >=0) {
			System.out.println("Numero decrescente: " + numero);
			numero --;
		}
	}	
}