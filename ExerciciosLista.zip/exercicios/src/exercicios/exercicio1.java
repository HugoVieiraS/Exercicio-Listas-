package exercicios;

public class exercicio1 extends exeAula {

	
	public int somar(int ano,int mes, int dia) {
	ano = ano*365;
	mes =  mes*30;
	
	return dia = dia + ano + mes;
	
	
	}

}
